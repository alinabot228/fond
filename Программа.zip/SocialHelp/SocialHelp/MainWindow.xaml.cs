﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Users f = new Users();
            f.ShowDialog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Categorys f = new Categorys();
            f.ShowDialog();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Questions f = new Questions();
            f.ShowDialog();
        }

        void fill()
        {
            THelps t = new THelps();
            t.GetForAdmin();//получаем всех пользоватлеей
            dg.ItemsSource = t.dt.AsDataView();//указываем источник записей для DataGrid
            dg.Columns[0].Header = "№ обращения";//скрываем столбец ID
            //оформление заголовков
            dg.Columns[1].Header = "ФИО";
            dg.Columns[2].Header = "Вопрос";
            dg.Columns[3].Header = "Дата регистрации";
            dg.Columns[3].ClipboardContentBinding.StringFormat = "dd.MM.yyyy HH:mm";
            dg.Columns[4].Header = "Телефон";
            dg.Columns[5].MaxWidth= 0;//скрываем столбец ID

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            fill();

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            System.Windows.Application.Current.Shutdown();//выход из приложения

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            THelps t = new THelps();
            t.IDUser = Authorization.ID_current_user;
            t.IDQuestion = int.Parse((dg.SelectedItem as DataRowView).Row["IDQuestion"].ToString());
            t.ID = int.Parse((dg.SelectedItem as DataRowView).Row["IDHelp"].ToString());
            t.Edit();
            System.Windows.MessageBox.Show("Данное обращение закрыто!");
            fill();
        }
    }
}

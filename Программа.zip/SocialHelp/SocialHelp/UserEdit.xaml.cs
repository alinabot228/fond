﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для UserEdit.xaml
    /// </summary>
    public partial class UserEdit : Window
    {
        int ID;
        public UserEdit(int ID)
        {
            InitializeComponent();
            this.ID = ID;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //если ID не 0, то заполняем поля из таблицы
            if (ID != 0)
            {
                TQuestion t = new TQuestion();
                t.ID = ID;
                t.GetByID();
                txtFIO.Text = t.dt.Rows[0]["Full_name_user"].ToString();
                txtTelephone.Text = t.dt.Rows[0]["telephone"].ToString();
                cbRole.Text = t.dt.Rows[0]["role"].ToString();
                txtLogin.Text = t.dt.Rows[0]["login"].ToString();
                txtPassword.Text = t.dt.Rows[0]["password"].ToString();
                dtBirthday.SelectedDate = DateTime.Parse(t.dt.Rows[0]["Birthday"].ToString());

            }
        }

        private void cancel_click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void save_click(object sender, RoutedEventArgs e)
        {
            //создаем экземпляр класса пользователя
            TQuestion t = new TQuestion();
            //задаем значения
            t.Full_name_user = txtFIO.Text;
            t.telephone= txtTelephone.Text;
            t.ID = ID;
            t.role = cbRole.Text.ToString();
            t.login = txtLogin.Text;
            t.password = txtPassword.Text;
            t.Birthday = DateTime.Parse(dtBirthday.SelectedDate.ToString());


            //если id =0, то добавление данных, если нет - обновление
            if (ID == 0)
            {
                t.Add();
            }
            else
            {
                t.Edit();
            }

            DialogResult = true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialHelp
{
    public class TQuestion
    {
        //переменные, которые используются в классе
        public int ID;
        public string Full_name_user;
        public DateTime Birthday;
        public string login;
        public string password;
        public string role;
        public string telephone;

        public DataTable dt = new DataTable("Users");
        SqlConnection conn = new SqlConnection(DBConnect.SQLConnString);

        // получение всех записей из таблицы Users
        public void Get()
        {
            string qrPostsList = "SELECT * FROM Users";//запрос

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);// параметры команды
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);//заполняем таблицу данными, которые возвращены на основании запроса

            conn.Close();
            da.Dispose();
        }

        // получение конкретной записи из таблицы Users по значению первичного ключа
        // аналогично Get, только заполняет таблицу одной записью
        public void GetByID()
        {
            string qrPostsList = "SELECT * FROM Users WHERE IDUser = @IDUser";

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);
            cmd.Parameters.AddWithValue("@IDUser", ID);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            conn.Close();
            da.Dispose();
        }

        //функция добавления данных в таблицу
        public void Add()
        {
            string qr = @"INSERT INTO Users(Full_name_user, Birthday, login, password, role, telephone) 
                            VALUES(@Full_name_user, @Birthday, @login, @password, @role, @telephone)";//запрос добавления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@Full_name_user", Full_name_user);
            cmd.Parameters.AddWithValue("@Birthday", Birthday);
            cmd.Parameters.AddWithValue("@login", login);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@role", role);
            cmd.Parameters.AddWithValue("@telephone", telephone);
            conn.Open();
            cmd.ExecuteNonQuery();//выполнения запроса
            conn.Close();
        }

        //функция обновления данных в таблице
        public void Edit()
        {
            string qr = @"UPDATE Users 
                        SET Full_name_user = @Full_name_user 
                        , Birthday = @Birthday
                        , login = @login
                        , password = @password
                        , role = @role
                        , telephone = @telephone
                        WHERE IDUser = @IDUser";//запрос обновления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@Full_name_user", Full_name_user);
            cmd.Parameters.AddWithValue("@Birthday", Birthday);
            cmd.Parameters.AddWithValue("@login", login);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@role", role);
            cmd.Parameters.AddWithValue("@telephone", telephone);
            cmd.Parameters.AddWithValue("@IDUser", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        //функция удаления данных в таблице
        public void Del()
        {
            string qr = "DELETE FROM Users WHERE IDUser = @IDUser";

            SqlCommand cmd = new SqlCommand(qr, conn);
            cmd.Parameters.AddWithValue("@IDUser", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}

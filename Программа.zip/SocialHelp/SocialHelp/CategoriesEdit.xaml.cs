﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для CategoriesEdit.xaml
    /// </summary>
    public partial class CategoriesEdit : Window
    {
        int ID;
        public CategoriesEdit(int ID)
        {
            InitializeComponent();
            this.ID = ID;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //если ID не 0, то заполняем поля из таблицы
            if (ID != 0)
            {
                TQuestion t = new TQuestion();
                t.ID = ID;
                t.GetByID();
                txtFIO.Text = t.dt.Rows[0]["title"].ToString();

            }
        }

        private void save_click(object sender, RoutedEventArgs e)
        {
            //создаем экземпляр класса пользователя
            TCategorys t = new TCategorys();
            //задаем значения
            t.Title = txtFIO.Text;
            t.ID = ID;

            //если id =0, то добавление данных, если нет - обновление
            if (ID == 0)
            {
                t.Add();
            }
            else
            {
                t.Edit();
            }

            DialogResult = true;
        }

        private void cancel_click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}

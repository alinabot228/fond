﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для MainUser.xaml
    /// </summary>
    public partial class MainUser : Window
    {
        BindingSource bsCategory = new BindingSource();
        BindingSource bsQuestions;
        public MainUser()
        {
            InitializeComponent();
        }

        public void fillCategory()
        {
            //содаем класс пользоватлеей
            TCategorys t = new TCategorys();
            t.Get();//получаем всех пользоватлеей
            bsCategory.DataSource = t.dt.AsDataView();
            dgCategoryList.ItemsSource = bsCategory;//указываем источник записей для DataGrid
            dgCategoryList.Columns[0].MaxWidth = 0;//скрываем столбец ID
            //оформление заголовков
            //dg.Columns[1].Header = "Отдел";
            dgCategoryList.Columns[1].Header = "Название";
        }

        public void fillQuestionByCategory()
        {
            bsQuestions = null;
            bsQuestions = new BindingSource();
            TQuestions t = new TQuestions();
            t.IDCategory = int.Parse((dgCategoryList.SelectedItem as DataRowView).Row["IDCategory"].ToString());
            t.GetListByCategoryID();//получаем всех пользоватлеей
            bsQuestions.DataSource = t.dt.AsDataView();
            dgQuestions.ItemsSource = bsQuestions;//указываем источник записей для DataGrid
            dgQuestions.Columns[0].MaxWidth = 0;//скрываем столбец ID
            dgQuestions.Columns[1].MaxWidth = 0;//скрываем столбец ID
            dgQuestions.Columns[4].MaxWidth = 0;//скрываем столбец ID
            //оформление заголовков
            dgQuestions.Columns[2].MaxWidth = 0;
            dgQuestions.Columns[3].Header = "Вопрос";

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            fillCategory();
        }

        private void dgCategoryList_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            //fillQuestionByCategory();
        }

        private void dgCategoryList_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            //System.Windows.MessageBox.Show((dgCategoryList.SelectedItem as DataRowView).Row["IDCategory"].ToString());
            fillQuestionByCategory();

        }
        public void fillSolutionByQuestion()
        {
            if (dgQuestions.SelectedItem != null)
                txtSolution.Text = (dgQuestions.SelectedItem as DataRowView).Row["Description_solution"].ToString();
        }
        private void dgQuestions_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            fillSolutionByQuestion();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            bsQuestions.Filter = "q_title like '%" + txtFind.Text + "%'";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (dgQuestions.SelectedItem == null)
            {
                System.Windows.MessageBox.Show("Укажите вопрос!");
                return;
            }
            THelps t = new THelps();
            t.IDUser = Authorization.ID_current_user;
            t.IDQuestion = int.Parse((dgQuestions.SelectedItem as DataRowView).Row["IDQuestion"].ToString());
            t.Add();
            System.Windows.MessageBox.Show("Ваш запрос был отправлен!");
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            System.Windows.Application.Current.Shutdown();//выход из приложения

        }
    }
}

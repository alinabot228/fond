﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для Questions.xaml
    /// </summary>
    public partial class Questions : Window
    {
        public Questions()
        {
            InitializeComponent();
        }

        private void fill()
        {
            //содаем класс пользоватлеей
            TQuestions t = new TQuestions();
            t.Get();//получаем всех пользоватлеей
            dg.ItemsSource = t.dt.AsDataView();//указываем источник записей для DataGrid
            dg.Columns[0].MaxWidth = 0;//скрываем столбец ID
            dg.Columns[1].MaxWidth = 0;//скрываем столбец ID
            dg.Columns[4].MaxWidth = 0;//скрываем столбец ID
            //оформление заголовков
            //dg.Columns[1].Header = "Отдел";
            dg.Columns[2].Header = "Категория";
            dg.Columns[3].Header = "Вопрос";

        }


        private void Del_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Удалить текущую запись?", "Осторожно", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                //создаем класс пользвоателей
                TQuestions t = new TQuestions();
                //передаем ID в экземпляр класса
                t.ID = int.Parse((this.dg.Columns[0].GetCellContent(this.dg.SelectedItem) as TextBlock).Text);
                t.Del();//удаляем запись
                fill();//обновляем данные в DataGrid
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (dg.SelectedIndex < 0) return;
            //создаем форму редактирования и передаем значение ID из текущей записи
            QuestionEdit f = new QuestionEdit(int.Parse((this.dg.Columns[0].GetCellContent(this.dg.SelectedItem) as TextBlock).Text));
            //если пользователь нажал "сохранить", то обновлем данные в таблице
            bool? dialogResult = f.ShowDialog();
            switch (dialogResult)
            {
                case true:
                    fill();
                    break;
                default:
                    // Indeterminate
                    break;
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            QuestionEdit f = new QuestionEdit(0);
            bool? dialogResult = f.ShowDialog();
            switch (dialogResult)
            {
                case true:
                    fill();
                    break;
                default:
                    // Indeterminate
                    break;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            fill();
        }
    }
}

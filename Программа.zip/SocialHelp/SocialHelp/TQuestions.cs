﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialHelp
{
    public class TQuestions
    {
        public int ID;
        public int IDCategory;
        public string Title;
        public string Description_solution;

        public DataTable dt = new DataTable("Questions");
        SqlConnection conn = new SqlConnection(DBConnect.SQLConnString);

        public void Get()
        {
            string qrPostsList = @"SELECT Questions.IDQuestion, Questions.IDCategory, Categorys.title, Questions.Title, Questions.Description_solution 
                                FROM Questions INNER JOIN Categorys ON Categorys.IDCategory = Questions.IDCategory";//запрос

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);// параметры команды
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);//заполняем таблицу данными, которые возвращены на основании запроса

            conn.Close();
            da.Dispose();
        }

        public void GetListByCategoryID()
        {
            string qrPostsList = @"SELECT Questions.IDQuestion, Questions.IDCategory, Categorys.title, Questions.Title as q_title, Questions.Description_solution 
                                FROM Questions INNER JOIN Categorys ON Categorys.IDCategory = Questions.IDCategory
                                WHERE Questions.IDCategory = "+IDCategory;//запрос

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);// параметры команды
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);//заполняем таблицу данными, которые возвращены на основании запроса

            conn.Close();
            da.Dispose();
        }

        public void GetByID()
        {
            string qrPostsList = "SELECT * FROM Questions WHERE IDQuestion = @IDQuestion";

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);
            cmd.Parameters.AddWithValue("@IDQuestion", ID);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            conn.Close();
            da.Dispose();
        }

        public void Add()
        {
            string qr = @"INSERT INTO Questions(IDCategory, Title, Description_solution) 
                            VALUES(@IDCategory, @Title, @Description_solution)";//запрос добавления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@IDCategory", IDCategory);
            cmd.Parameters.AddWithValue("@Title", Title);
            cmd.Parameters.AddWithValue("@Description_solution", Description_solution);
            conn.Open();
            cmd.ExecuteNonQuery();//выполнения запроса
            conn.Close();
        }

        public void Edit()
        {
            string qr = "UPDATE Questions SET IDCategory = @IDCategory, Title = @Title, Description_solution = @Description_solution WHERE IDQuestion = @IDQuestion";//запрос обновления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@IDCategory", IDCategory);
            cmd.Parameters.AddWithValue("@Title", Title);
            cmd.Parameters.AddWithValue("@Description_solution", Description_solution);
            cmd.Parameters.AddWithValue("@IDQuestion", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void Del()
        {
            string qr = "DELETE FROM Questions WHERE IDQuestion = @IDQuestion";

            SqlCommand cmd = new SqlCommand(qr, conn);
            cmd.Parameters.AddWithValue("@IDQuestion", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}

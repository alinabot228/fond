﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialHelp
{
    public class TCategorys
    {
        //переменные, которые используются в классе
        public int ID;
        public string Title;

        public DataTable dt = new DataTable("Categorys");
        SqlConnection conn = new SqlConnection(DBConnect.SQLConnString);

        // получение всех записей из таблицы Categorys
        public void Get()
        {
            string qrPostsList = "SELECT * FROM Categorys";//запрос

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);// параметры команды
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);//заполняем таблицу данными, которые возвращены на основании запроса

            conn.Close();
            da.Dispose();
        }

        // получение конкретной записи из таблицы Categorys по значению первичного ключа
        // аналогично Get, только заполняет таблицу одной записью
        public void GetByID()
        {
            string qrPostsList = "SELECT * FROM Categorys WHERE IDCategory = @IDCategory";

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);
            cmd.Parameters.AddWithValue("@IDCategory", ID);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            conn.Close();
            da.Dispose();
        }

        //функция добавления данных в таблицу
        public void Add()
        {
            string qr = "INSERT INTO Categorys(title) VALUES(@title)";//запрос добавления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@title", Title);// передаем параметры в команду, значение переменной из строки 15
            conn.Open();
            cmd.ExecuteNonQuery();//выполнения запроса
            conn.Close();
        }

        //функция обновления данных в таблице
        public void Edit()
        {
            string qr = "UPDATE Categorys SET title = @title WHERE IDCategory = @IDCategory";//запрос обновления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@title", Title);// передаем параметры в команду
            cmd.Parameters.AddWithValue("@IDCategory", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        //функция удаления данных в таблице
        public void Del()
        {
            string qr = "DELETE FROM Categorys WHERE IDCategory = @IDCategory";

            SqlCommand cmd = new SqlCommand(qr, conn);
            cmd.Parameters.AddWithValue("@IDCategory", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}

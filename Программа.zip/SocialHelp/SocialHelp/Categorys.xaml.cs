﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для Categorys.xaml
    /// </summary>
    public partial class Categorys : Window
    {
        public Categorys()
        {
            InitializeComponent();
        }

        private void fill()
        {
            //содаем класс пользоватлеей
            TCategorys t = new TCategorys();
            t.Get();//получаем всех пользоватлеей
            dg.ItemsSource = t.dt.AsDataView();//указываем источник записей для DataGrid
            dg.Columns[0].MaxWidth = 0;//скрываем столбец ID
            //оформление заголовков
            //dg.Columns[1].Header = "Отдел";
            dg.Columns[1].Header = "Название";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            fill();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            //открываем форму редактирования пользователя для добавления
            CategoriesEdit f = new CategoriesEdit(0);
            //если пользователь нажал "Сохранить", то обновляем таблицу
            bool? dialogResult = f.ShowDialog();
            switch (dialogResult)
            {
                case true:
                    fill();
                    break;
                default:
                    // Indeterminate
                    break;
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (dg.SelectedIndex < 0) return;
            //создаем форму редактирования и передаем значение ID из текущей записи
            CategoriesEdit f = new CategoriesEdit(int.Parse((this.dg.Columns[0].GetCellContent(this.dg.SelectedItem) as TextBlock).Text));
            //если пользователь нажал "сохранить", то обновлем данные в таблице
            bool? dialogResult = f.ShowDialog();
            switch (dialogResult)
            {
                case true:
                    fill();
                    break;
                default:
                    // Indeterminate
                    break;
            }
        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Удалить текущую запись?", "Осторожно", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                //создаем класс пользвоателей
                TCategorys t = new TCategorys();
                //передаем ID в экземпляр класса
                t.ID = int.Parse((this.dg.Columns[0].GetCellContent(this.dg.SelectedItem) as TextBlock).Text);
                t.Del();//удаляем запись
                fill();//обновляем данные в DataGrid
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SocialHelp
{
    /// <summary>
    /// Логика взаимодействия для QuestionEdit.xaml
    /// </summary>
    public partial class QuestionEdit : Window
    {
        int ID;
        public QuestionEdit(int ID)
        {
            InitializeComponent();
            this.ID = ID;
        }

        private void cancel_click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
        private void FillCB()
        {
            TCategorys d = new TCategorys();
            d.Get();//получаем все отделы
            cbCategory.ItemsSource = d.dt.DefaultView;//назначаем источник записи для выпадающего списка
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //если ID не 0, то заполняем поля из таблицы
            if (ID != 0)
            {
                TQuestions t = new TQuestions();
                t.ID = ID;
                t.GetByID();
                txtQuestion.Text = t.dt.Rows[0]["Title"].ToString();
                txtSolution.Text = t.dt.Rows[0]["Description_solution"].ToString();
                cbCategory.SelectedValue = int.Parse(t.dt.Rows[0]["IDCategory"].ToString());

            }
            FillCB();
        }

        private void save_click(object sender, RoutedEventArgs e)
        {
            TQuestions t = new TQuestions();
            t.Title = txtQuestion.Text;
            t.Description_solution = txtSolution.Text;
            t.IDCategory = int.Parse(cbCategory.SelectedValue.ToString());
            t.ID = ID;
            
            if (ID == 0)
            {
                t.Add();
            }
            else
            {
                t.Edit();
            }

            DialogResult = true;
        }
    }
}

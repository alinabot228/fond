﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialHelp
{
    public class THelps
    {
        public int ID;
        public int IDUser;
        public int IDQuestion;

        public DataTable dt = new DataTable("Helps");
        SqlConnection conn = new SqlConnection(DBConnect.SQLConnString);

        public void GetForAdmin()
        {
            string qrPostsList = @"SELECT h.IDHelp, u.Full_name_user, q.Title, h.Date_reg, u.telephone, q.IDQuestion
                    FROM Helps h
                    INNER JOIN Users u ON h.idUser = u.IDUser
                    INNER JOIN Questions q ON q.IDQuestion = h.IDQuestion
                    WHERE h.Date_ok is null";//запрос

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);// параметры команды
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);//заполняем таблицу данными, которые возвращены на основании запроса

            conn.Close();
            da.Dispose();
        }

        public void GetByID()
        {
            string qrPostsList = "SELECT * FROM Helps WHERE IDHelp = @IDHelp";

            SqlCommand cmd = new SqlCommand(qrPostsList, conn);
            cmd.Parameters.AddWithValue("@IDHelp", ID);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            conn.Close();
            da.Dispose();
        }

        public void Add()
        {
            string qr = @"INSERT INTO Helps(IDUser, IDQuestion, Date_reg) 
                            VALUES(@IDUser, @IDQuestion, @Date_reg)";//запрос добавления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@IDUser", IDUser);
            cmd.Parameters.AddWithValue("@IDQuestion", IDQuestion);
            cmd.Parameters.AddWithValue("@Date_reg", DateTime.Now);
            conn.Open();
            cmd.ExecuteNonQuery();//выполнения запроса
            conn.Close();
        }

        public void Edit()
        {
            string qr = @"UPDATE Helps 
                        SET IDUser = @IDUser 
                        , IDQuestion = @IDQuestion
                        , Date_ok = @Date_ok
                        WHERE IDHelp = @IDHelp";//запрос обновления

            SqlCommand cmd = new SqlCommand(qr, conn);//создаем команду
            cmd.Parameters.AddWithValue("@IDUser", IDUser);
            cmd.Parameters.AddWithValue("@IDQuestion", IDQuestion);
            cmd.Parameters.AddWithValue("@IDHelp", ID);
            cmd.Parameters.AddWithValue("@Date_ok", DateTime.Now);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void Del()
        {
            string qr = "DELETE FROM Helps WHERE IDHelp = @IDHelp";

            SqlCommand cmd = new SqlCommand(qr, conn);
            cmd.Parameters.AddWithValue("@IDHelp", ID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}

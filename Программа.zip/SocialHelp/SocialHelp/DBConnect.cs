﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialHelp
{
    class DBConnect
    {
        //строка подключения к БД
        public static string SQLConnString = "Data Source=PC\\PC;Initial Catalog=SocialHelp;Integrated Security=True";

    }
}
